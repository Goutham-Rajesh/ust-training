package com.demo.monolithic_spring_security_product_demo.Controller;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.demo.monolithic_spring_security_product_demo.Entity.Credential;

@RestController
@RequestMapping("/api")
public class CredentialController {
    @PostMapping("/authusers/validate")
    public Credential validate(@RequestBody Credential user){
        return null;
    }
}
