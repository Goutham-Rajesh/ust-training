package com.demo.monolithic_spring_security_product_demo.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.monolithic_spring_security_product_demo.Entity.Product;
import com.demo.monolithic_spring_security_product_demo.Repository.ProductRepository;

@Service
public class ProductService {

    @Autowired
    ProductRepository productRepository;

    public List<Product> getAllProdut(){
        return productRepository.findAll();
    }

    public Product getAProduct(int prodId){
        return productRepository.findById(prodId).orElse(null);
    }
    
    public Product addProduct(Product product){
        return productRepository.saveAndFlush(product);
        
    }
}
