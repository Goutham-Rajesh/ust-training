package com.demo.monolithic_spring_security_product_demo.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.demo.monolithic_spring_security_product_demo.Entity.Product;
import com.demo.monolithic_spring_security_product_demo.Service.ProductService;

@RestController
@RequestMapping("/api")
public class ProductController {
    
    @Autowired
    ProductService productService;

    @PreAuthorize("hasAuthority('ROLE_USER')")
    @GetMapping("/products")
    public List<Product> getAllProducts(){
        return productService.getAllProdut();
    }

    @PreAuthorize("hasAuthority('ROLE_ADMIN')")
    @GetMapping("/products/{pid}")
    public Product getAProduct(@PathVariable("pid") int prodId){
        return productService.getAProduct(prodId);
    }

    @PreAuthorize("hasAuthority('ROLE_ADMIN')")
    @PostMapping("/products")
    public Product addProduct(@RequestBody Product product){
        return productService.addProduct(product);
    }
}
