package com.demo.monolithic_spring_security_product_demo.Repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.demo.monolithic_spring_security_product_demo.Entity.Credential;

@Repository
public interface CredentialRepository extends JpaRepository<Credential,Integer> {

    Optional<Credential> findByCredUser(String credUser);

    
}