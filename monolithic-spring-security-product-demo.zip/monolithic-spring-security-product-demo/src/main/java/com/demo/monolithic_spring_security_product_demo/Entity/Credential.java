package com.demo.monolithic_spring_security_product_demo.Entity;

import java.util.List;


import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Data
@Table(name="user_details")
public class Credential {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int credId;
    private String credUser;
    private String credPassword;

    @ManyToMany
    @JoinTable(name="credential_role",joinColumns = @JoinColumn(name="cred_id"),inverseJoinColumns = @JoinColumn(name="role_id"))
    List<Roles> allRoles;
    
}
