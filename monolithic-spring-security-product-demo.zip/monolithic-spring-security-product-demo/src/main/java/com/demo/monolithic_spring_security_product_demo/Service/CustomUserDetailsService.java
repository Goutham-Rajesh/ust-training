package com.demo.monolithic_spring_security_product_demo.Service;


import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.demo.monolithic_spring_security_product_demo.Entity.Credential;
import com.demo.monolithic_spring_security_product_demo.Entity.CustomUserDetails;
import com.demo.monolithic_spring_security_product_demo.Repository.CredentialRepository;

@Service
public class CustomUserDetailsService implements UserDetailsService {

    @Autowired
    CredentialRepository credentialRepository;


    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        
        Optional<Credential> credUser = credentialRepository.findByCredUser(username);
        return credUser
		.map((user)->new CustomUserDetails(user.getCredUser(), user.getCredPassword(), user.getAllRoles()))
		.orElseThrow(()-> new UsernameNotFoundException(username + " not found"));
    } 
}
