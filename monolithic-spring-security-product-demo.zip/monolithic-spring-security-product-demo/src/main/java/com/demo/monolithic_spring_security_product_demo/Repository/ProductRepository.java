package com.demo.monolithic_spring_security_product_demo.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.demo.monolithic_spring_security_product_demo.Entity.Product;

public interface ProductRepository extends JpaRepository<Product,Integer> {

    
}